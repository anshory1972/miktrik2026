*==============================================================================
* SYNTHETIC SUSENAS - PMT ASSIGNMENT
* Step 2: the proxy means test as a linear model
*
* Two models, both fitted on the three training rounds 2022-2024 with a fixed
* effect for every district, and both used to predict the 2025 round the model
* has never seen:
*   1. the PMT: the BPS / World Bank set of thirty-nine proxies
*   2. a parsimonious model of eight underlying variables
*
* Nothing is scored here. Step 3 fits the same two specifications as ordered
* probit and then judges all four predictions together.
*==============================================================================

clear all
set more off

* THE LINES TO EDIT before running this file:
*   work  the same folder you gave step 0; the earlier steps left their files there
global work "E:/pmtwb/synthetic_mc/work_assignment"
capture mkdir "$work"

* every step writes its own log into that folder; hand the four logs in with the do files
capture log close
log using "$work/s2_pmt_ols.log", replace text


*==============================================================================
* THE SPECIFICATIONS
*==============================================================================

* The PMT: the BPS / World Bank set of proxies, written out.
global baseline_39                                    ///
    ln_hhsize                                         ///
    ln_hhsize_2                                       ///
    ln_h_luaslantai                                   ///
    ln_h_luaslantai_2                                 ///
    i.h_house                                         ///
    i.h_roof                                          ///
    i.h_wall                                          ///
    i.h_floor                                         ///
    i.h_toilet                                        ///
    i.h_closet                                        ///
    i.h_sewage                                        ///
    i.h_water                                         ///
    i.h_light                                         ///
    i.h_fuel                                          ///
    i.h_epower                                        ///
    h_asset_a h_asset_b h_asset_c h_asset_d           ///
    h_asset_e h_asset_f h_asset_g h_asset_h           ///
    h_asset_i h_asset_j h_asset_k h_asset_l h_asset_m ///
    n_age04 n_age519 n_age2064 n_age65up              ///
    n_female n_worker                                 ///
    h_married h_widowed                               ///
    h_neverschool h_stillschool                       ///
    head_female hd_age hd_edu

* The parsimonious model. Eight underlying variables, written out as the fifteen
* terms they enter as: household size, electricity in kilowatt hours per head,
* telecommunications spending per head, each with a square; the meter capacity
* dummies and their interaction with electricity; three assets; and floor area
* with its square.
global predictors_7                                   ///
    ln_hhsize                                         ///
    ln_elec_kwh_pc                                    ///
    ln_telecom_cons_pc                                ///
    ln_hhsize_2                                       ///
    ln_elec_kwh_pc_2                                  ///
    ln_telecom_cons_pc_2                              ///
    h_epower2                                         ///
    h_epower3                                         ///
    ln_elec_kwh_pc_h_epower2                          ///
    ln_elec_kwh_pc_h_epower3                          ///
    h_asset_car                                       ///
    h_asset_computer                                  ///
    h_asset_land                                      ///
    ln_h_luaslantai                                   ///
    ln_h_luaslantai_2


*==============================================================================
* THE SAMPLE
*
* Training and test go in one file with a flag, so that a single `predict` after
* estimation fills the test rows as well. `train` marks the rounds the model is
* allowed to learn from.
*==============================================================================
use "$work/train_2022_2024.dta", clear
generate byte train = 1
append using "$work/test_2025.dta"
replace train = 0 if missing(train)
tabulate year train

* Assets are coded 1 = yes and 5 = no in the raw data. The three the
* parsimonious model uses were already recoded in step 1; the other ten are
* recoded here because the PMT uses all thirteen.
replace h_asset_a = (h_asset_a == 1)
replace h_asset_b = (h_asset_b == 1)
replace h_asset_c = (h_asset_c == 1)
replace h_asset_d = (h_asset_d == 1)
replace h_asset_e = (h_asset_e == 1)
replace h_asset_f = (h_asset_f == 1)
replace h_asset_g = (h_asset_g == 1)
replace h_asset_h = (h_asset_h == 1)
replace h_asset_i = (h_asset_i == 1)
replace h_asset_j = (h_asset_j == 1)
replace h_asset_k = (h_asset_k == 1)
replace h_asset_l = (h_asset_l == 1)
replace h_asset_m = (h_asset_m == 1)


*==============================================================================
* A TRAP WORTH STOPPING ON
*
* Four variables are missing for a REASON, not at random:
*   h_closet and h_sewage are missing exactly when the household has no toilet
*   h_epower  is missing exactly when lighting does not come from the grid
*   hd_edu    is genuinely missing for a share of heads, mostly the oldest
*
* Write i.h_closet and Stata drops every one of those households from the
* regression and says nothing about it. The model is then fitted on households
* that all have a toilet and a grid connection, which is not the population you
* meant to study, and part of the test round gets no prediction at all.
*
* The fix is to make "not applicable" its own category and keep the rows. The
* counts printed here are part of the reference output: if yours differ, your
* build differs.
*==============================================================================
count if missing(h_closet)
replace h_closet = 99 if missing(h_closet)

count if missing(h_sewage)
replace h_sewage = 99 if missing(h_sewage)

count if missing(h_epower)
replace h_epower = 99 if missing(h_epower)

count if missing(hd_edu)
replace hd_edu = 99 if missing(hd_edu)


*==============================================================================
* 1. THE PMT, WITH DISTRICT FIXED EFFECTS
*
* Fitted on the three training rounds only. i.kode_kab gives every district its
* own intercept: 514 dummies. They are part of the model but not of the output -
* the regression is run quietly and `estimates table` prints the proxies alone.
* The prediction is made for EVERY household, including the 2025 test round.
*==============================================================================
di as result _n "{hline 70}" _n "1. The PMT, district fixed effects" _n "{hline 70}"
quietly regress lnrpcexp $baseline_39 urban i.kode_kab if train == 1
estimates table, drop(i.kode_kab) b(%9.4f) se(%9.4f) stats(N r2_a rmse) varwidth(28)

predict double yhat_pmt, xb


*==============================================================================
* 2. THE PARSIMONIOUS MODEL, WITH DISTRICT FIXED EFFECTS
*
* Same sample, same district effects, the other list of proxies.
*==============================================================================
di as result _n "{hline 70}" _n "2. The parsimonious model, district fixed effects" _n "{hline 70}"

* Same pattern as model 1, with the other list of proxies, and the prediction
* saved as yhat_pars - step 3 expects that name.
*
* >>> write model 2 here <<<


*==============================================================================
* SAVE FOR STEP 3
*==============================================================================
quietly save "$work/step2_predictions.dta", replace
di as result _n "Step 2 complete."
log close
