*==============================================================================
* SYNTHETIC SUSENAS - PMT ASSIGNMENT
* Step 1: build one household-level analysis file per round
*
* What you are practising here:
*   - collapsing person records into household counts
*   - merging a household file, an expenditure summary and a consumption module
*   - reshaping item-level consumption from long to wide
*   - deflating expenditure to one base price and ranking weighted deciles
*
* HOW THIS FILE IS ORGANISED. March 2022 is written out in full with the
* commentary. The other three rounds repeat the same steps and are yours to
* write. Not all Susenas rounds are the same: variable names and answer codes
* change between rounds, and a name that no longer exists does not always
* produce an error. For every field this file uses, go back to the source:
* the question in the round's questionnaire (kuesioner/), then the field name
* and the codes in the round's metadata workbook. Reading the questionnaire
* before the data is the habit this exercise is meant to build.
*==============================================================================

clear all
set more off

* THE LINES TO EDIT before running this file:
*   work  the same folder you gave step 0; the earlier steps left their files there
global work "E:/pmtwb/synthetic_mc/work_assignment"
capture mkdir "$work"

* every step writes its own log into that folder; hand the four logs in with the do files
capture log close
log using "$work/s1_build.log", replace text

* the deflator base: the DKI Jakarta 2022 urban poverty line. Every round and
* every district is expressed in these prices so that one decile ranking means
* the same thing everywhere.
global anchor 738955


*==============================================================================
*==============================================================================
* MARCH 2022
*==============================================================================
*==============================================================================
di as result _n "{hline 70}" _n "Building March 2022" _n "{hline 70}"

*------------------------------------------------------------------------------
* 1A. Collapse the individual file into household counts.
*
* This is the operation the whole package exists to teach. The individual file
* has one row per person; the model needs one row per household. Everything
* below is a count of people with some characteristic, so `collapse (sum)` of a
* 0/1 indicator is the natural way to do it.
*------------------------------------------------------------------------------
use "$work/ind_2022.dta", clear

* age groups
generate byte n_age04   = inrange(r407, 0, 4)
generate byte n_age519  = inrange(r407, 5, 19)
generate byte n_age2064 = inrange(r407, 20, 64)
generate byte n_age65up = r407 >= 65 & !missing(r407)

* sex
generate byte n_male   = r405 == 1
generate byte n_female = r405 == 2

* marital status
generate byte h_notmarried = r404 == 1
generate byte h_married    = r404 == 2
generate byte h_divorced   = r404 == 3
generate byte h_widowed    = r404 == 4

* school attendance. r610 in this round. It is asked of people aged 5 and over
* and is blank for everyone younger, so these counts are over the eligible only.
generate byte h_neverschool = r610 == 1
generate byte h_stillschool = r610 == 2
generate byte h_notschool   = r610 == 3

* a worker is anyone with a job sector recorded. r705 in this round.
generate byte n_worker = !missing(r705)

* the head of the household is relationship code 1
generate byte head_female = (r405 == 2) & (r403 == 1)
generate hd_age = r407 if r403 == 1
generate hd_edu = r614 if r403 == 1

* r802 (smartphone) and r808 (internet) are INDIVIDUAL questions that the PMT
* treats as household characteristics. The convention is to take the first
* listed member, so sort and take the first row.
sort urut r401
by urut: generate byte first_member = _n == 1
generate byte pr802 = r802 if first_member
generate byte pr808 = r808 if first_member

collapse (sum) n_age04 n_age519 n_age2064 n_age65up n_male n_female            ///
               h_notmarried h_married h_divorced h_widowed                     ///
               h_neverschool h_stillschool h_notschool n_worker head_female    ///
         (max) hd_age hd_edu pr802 pr808                                       ///
         (count) hhsize_ind = r401, by(urut)

label variable hhsize_ind "members counted from the individual file"
save "$work/hhagg_2022.dta", replace

*------------------------------------------------------------------------------
* 1B. Module 42 from long to wide.
*
* The module has one row per household per item bought. The model needs three
* numbers per household. b42k3 is a QUANTITY (kilowatt hours for electricity);
* b42k4 is a VALUE in rupiah.
*
* TRAP: the module carries one all-zero row (item code 0) for each household
* that bought none of the three items. Keep it. `collapse (max)` then returns
* zero for those households instead of missing, and they stay in the sample.
* Drop that row and you silently drop about a quarter of one per cent of
* households from every model you fit afterwards.
*------------------------------------------------------------------------------
use "$work/b42_2022.dta", clear
keep urut kode b42k3 b42k4

generate double kwh     = b42k3 if kode == 205
generate double credit  = b42k4 if kode == 236
generate double package = b42k4 if kode == 238

collapse (max) kwh credit package, by(urut)
replace kwh     = 0 if missing(kwh)
replace credit  = 0 if missing(credit)
replace package = 0 if missing(package)
di as text "households in module 42: " _N
save "$work/mod42_2022.dta", replace

*------------------------------------------------------------------------------
* 1C. Assemble the household record.
*
* The housing and asset variables are renamed to one common vocabulary so that
* steps 2 and 3 do not have to know which round they are reading. The names on
* the left of each rename are this round's names.
*------------------------------------------------------------------------------
use "$work/rt_2022.dta", clear

rename r1802  h_house
rename r1804  h_luaslantai
rename r1806  h_roof
rename r1807  h_wall
rename r1808  h_floor
rename r1809a h_toilet
rename r1809b h_closet
rename r1809c h_sewage
rename r1810a h_water
rename r1816  h_light
rename r1816b1 h_epower
rename r1817  h_fuel
rename r1801  h_nfam

rename r2001a h_asset_a
rename r2001b h_asset_b
rename r2001c h_asset_c
rename r2001d h_asset_d
rename r2001e h_asset_e
rename r2001f h_asset_f
rename r2001g h_asset_g
rename r2001h h_asset_h
rename r2001i h_asset_i
rename r2001j h_asset_j
rename r2001k h_asset_k
rename r2001l h_asset_l
rename r2001m h_asset_m

merge 1:1 urut using "$work/b43_2022.dta", keep(match) nogenerate ///
    keepusing(food nonfood expend kapita wert weind)
merge 1:1 urut using "$work/hhagg_2022.dta", keep(match) nogenerate
merge 1:1 urut using "$work/mod42_2022.dta", keep(match) nogenerate

generate int year = 2022
merge m:1 year r101 r105 using "$work/povline.dta", keep(match) nogenerate

*------------------------------------------------------------------------------
* 1D. Check before trusting.
*
* Household size can be got three different ways: from the expenditure
* identity, from the household file, and by counting person rows. If they
* disagree, something in the merge went wrong. `assert` stops the do file rather
* than letting a broken file through.
*------------------------------------------------------------------------------
generate hhsize = round(expend / kapita)
assert hhsize == r301
assert hhsize == hhsize_ind
assert abs(food + nonfood - expend) < 1
assert abs(weind - wert * hhsize) < 0.01

*------------------------------------------------------------------------------
* 1E. The model variables.
*------------------------------------------------------------------------------
* real per-capita expenditure: the welfare measure the PMT tries to predict
generate double rpcexp   = kapita * $anchor / povline
generate double lnrpcexp = ln(rpcexp)

generate double elec_kwh_pc     = kwh / hhsize
generate double telecom_cons_pc = (credit + package) / hhsize

* the + 0.1 exists only so that households with zero do not drop out of a log
generate ln_hhsize          = ln(hhsize)
generate ln_elec_kwh_pc     = ln(elec_kwh_pc + 0.1)
generate ln_telecom_cons_pc = ln(telecom_cons_pc + 0.1)
generate ln_h_luaslantai    = ln(h_luaslantai + 0.1)

generate ln_hhsize_2          = ln_hhsize ^ 2
generate ln_elec_kwh_pc_2     = ln_elec_kwh_pc ^ 2
generate ln_telecom_cons_pc_2 = ln_telecom_cons_pc ^ 2
generate ln_h_luaslantai_2    = ln_h_luaslantai ^ 2

* the electricity meter capacity, as two dummies. Category 1 is the base.
generate byte h_epower2 = h_epower == 2
generate byte h_epower3 = h_epower == 3
generate ln_elec_kwh_pc_h_epower2 = ln_elec_kwh_pc * h_epower2
generate ln_elec_kwh_pc_h_epower3 = ln_elec_kwh_pc * h_epower3

* assets are coded 1 = yes and 5 = no in the raw data, NOT 1 and 0
generate byte h_asset_car      = h_asset_k == 1
generate byte h_asset_computer = h_asset_f == 1
generate byte h_asset_land     = h_asset_m == 1

generate byte urban = r105 == 1
generate long kode_kab = r101 * 100 + r102

compress
save "$work/analysis_2022.dta", replace
di as result "March 2022: " _N " households built"

* CHECKPOINT. Compare every number in this table with the reference output
* before going on. If one of them differs, the error is in this round, above.
tabstat hhsize expend kwh credit package h_luaslantai n_worker hd_age lnrpcexp, ///
    statistics(mean sd min max) format(%12.2f) columns(statistics)


*==============================================================================
*==============================================================================
* MARCH 2023
*==============================================================================
*==============================================================================
di as result _n "{hline 70}" _n "Building March 2023" _n "{hline 70}"

* Not all Susenas rounds are the same. File names, the number of files a module is
* split into, variable names and answer codes all differ between rounds. Before
* you type anything for this round, open two things in its folder:
*   1. kuesioner/  - the questionnaire. Find the QUESTION you need (the block and
*      the item number); the variable is named after it.
*   2. the metadata workbook (Metadata_Synthetic_Susenas_YYYYMM.xlsx) - the
*      sheets "variabel ruta" and "variabel individu" give the field name for
*      each question, "value label" gives the answer codes.
* Then tabulate the field once to see that the codes are what the workbook says.
* The 2022 block above is the pattern; the 2025 round is the one that differs
* most.
*
* >>> write this round here <<<


*==============================================================================
*==============================================================================
* MARCH 2024
*==============================================================================
*==============================================================================
di as result _n "{hline 70}" _n "Building March 2024" _n "{hline 70}"

* Not all Susenas rounds are the same. File names, the number of files a module is
* split into, variable names and answer codes all differ between rounds. Before
* you type anything for this round, open two things in its folder:
*   1. kuesioner/  - the questionnaire. Find the QUESTION you need (the block and
*      the item number); the variable is named after it.
*   2. the metadata workbook (Metadata_Synthetic_Susenas_YYYYMM.xlsx) - the
*      sheets "variabel ruta" and "variabel individu" give the field name for
*      each question, "value label" gives the answer codes.
* Then tabulate the field once to see that the codes are what the workbook says.
* The 2022 block above is the pattern; the 2025 round is the one that differs
* most.
*
* >>> write this round here <<<


*==============================================================================
*==============================================================================
* MARCH 2025
*==============================================================================
*==============================================================================
di as result _n "{hline 70}" _n "Building March 2025" _n "{hline 70}"

* Not all Susenas rounds are the same. File names, the number of files a module is
* split into, variable names and answer codes all differ between rounds. Before
* you type anything for this round, open two things in its folder:
*   1. kuesioner/  - the questionnaire. Find the QUESTION you need (the block and
*      the item number); the variable is named after it.
*   2. the metadata workbook (Metadata_Synthetic_Susenas_YYYYMM.xlsx) - the
*      sheets "variabel ruta" and "variabel individu" give the field name for
*      each question, "value label" gives the answer codes.
* Then tabulate the field once to see that the codes are what the workbook says.
* The 2022 block above is the pattern; the 2025 round is the one that differs
* most.
*
* >>> write this round here <<<


*==============================================================================
* DECILES
*
* Two rules, and they are not arbitrary.
*
* First, the three training rounds are ranked TOGETHER. The model has to see one
* consistent welfare ranking; if each round were ranked separately, decile 1 in
* 2022 and decile 1 in 2024 would mean different living standards.
*
* Second, 2025 is ranked ON ITS OWN. It is the test round. Ranking it inside the
* training pool would let information from the test period leak into the
* training ranking.
*
* Weighted, with the individual weight, because a decile is a tenth of PEOPLE,
* not a tenth of households. A household of eight counts for eight.
*==============================================================================
use "$work/analysis_2022.dta", clear
append using "$work/analysis_2023.dta"
append using "$work/analysis_2024.dta"
replace weind = round(weind)
xtile decile = rpcexp [fweight = weind], nquantiles(10)
tabulate decile [fweight = weind]
save "$work/train_2022_2024.dta", replace
di as result "training sample: " _N " households"

use "$work/analysis_2025.dta", clear
replace weind = round(weind)
xtile decile = rpcexp [fweight = weind], nquantiles(10)
tabulate decile [fweight = weind]
save "$work/test_2025.dta", replace
di as result "test sample: " _N " households"

di as result _n "Step 1 complete."
log close
