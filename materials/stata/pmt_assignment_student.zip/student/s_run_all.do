*==============================================================================
* SYNTHETIC SUSENAS - PMT ASSIGNMENT
* Master file: run the whole exercise from the delivered dBase files
*
*   step 0, import        the dBase files of the four rounds        about 2 minutes
*   step 1, build         one household-level file per round        about 4 minutes
*   step 2, linear PMT    two models, district fixed effects        about 4 minutes
*   step 3, ordered PMT   two ordered probits, then the targeting errors  about 6 minutes
*
* Everything the four steps print goes to one log, student.log, next to this file.
*==============================================================================

clear all
set more off

* THE ONLY THREE LINES TO EDIT: where the do files are, where the dBase release is, and a
* folder for the intermediate Stata files (created if it does not exist)
global do   "E:/pmtwb/synthetic_mc/assignment/student"
global pkg  "E:/pmtwb/synthetic_mc/package_stata"
global work "E:/pmtwb/synthetic_mc/work_assignment"

capture log close
log using "$do/student.log", replace text

do "$do/s0_import.do"
do "$do/s1_build.do"
do "$do/s2_pmt_ols.do"
do "$do/s3_pmt_ordered.do"

di as result _n "{hline 70}"
di as result "All four steps complete."
di as result "{hline 70}"
log close
