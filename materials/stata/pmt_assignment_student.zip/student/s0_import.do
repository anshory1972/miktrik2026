*==============================================================================
* SYNTHETIC SUSENAS - PMT ASSIGNMENT
* Step 0: import the delivered dBase files
*
* Finish this file so that it runs from start to end.
*
* What you are practising here:
*   - reading a BPS dBase delivery into Stata with `import dbase`
*   - appending the files BPS splits by province code range
*   - noticing that BPS does not name the files the same way in every round
*
* March 2022 is written out in full below. Write the other three rounds the
* same way, one block each. Not all Susenas rounds are the same: read the
* file names in each round's folder before you type them.
*
* Note the forward slashes in the paths. Stata accepts them on Windows, and a
* backslash immediately before a macro is read as an escape character, which
* fails quietly.
*==============================================================================

clear all
set more off

if "$pkg" == "" global pkg  "E:/pmtwb/synthetic_mc/package_stata"      // a default; s_run_all.do sets it for all four files
if "$work" == "" global work "E:/pmtwb/synthetic_mc/work_assignment"      // a default; s_run_all.do sets it for all four files
capture mkdir "$work"


*==============================================================================
* MARCH 2022
*==============================================================================
di as result _n "{hline 70}" _n "March 2022" _n "{hline 70}"

* household KOR
import dbase using "$pkg/2022_maret/KOR/KOR22RT.dbf", clear
rename *, lower
di as text "KOR22RT: " _N " rows"
save "$work/rt_2022.dta", replace

* individual KOR. 2022 has one individual file only: no original second-half
* header for this round exists, so the package does not invent one.
import dbase using "$pkg/2022_maret/KOR/KOR22IND_1.dbf", clear
rename *, lower
di as text "KOR22IND_1: " _N " rows"
save "$work/ind_2022.dta", replace

* BLOK43, the expenditure summary, split into three province ranges.
* Note the third range is 51_94 in 2022 and 51_97 later: the Papua provinces
* were split in 2022, which extended the province codes.
import dbase using "$pkg/2022_maret/KP/blok43_11_31.dbf", clear
rename *, lower
save "$work/b43_2022.dta", replace
import dbase using "$pkg/2022_maret/KP/blok43_32_36.dbf", clear
rename *, lower
append using "$work/b43_2022.dta"
save "$work/b43_2022.dta", replace
import dbase using "$pkg/2022_maret/KP/blok43_51_94.dbf", clear
rename *, lower
append using "$work/b43_2022.dta"
isid urut
di as text "blok43, 3 files appended: " _N " rows"
save "$work/b43_2022.dta", replace

* BLOK42, the item-level consumption module, also split three ways
import dbase using "$pkg/2022_maret/KP/blok42_11_31.dbf", clear
rename *, lower
save "$work/b42_2022.dta", replace
import dbase using "$pkg/2022_maret/KP/blok42_32_36.dbf", clear
rename *, lower
append using "$work/b42_2022.dta"
save "$work/b42_2022.dta", replace
import dbase using "$pkg/2022_maret/KP/blok42_51_94.dbf", clear
rename *, lower
append using "$work/b42_2022.dta"
di as text "blok42, 3 files appended: " _N " rows"
save "$work/b42_2022.dta", replace


*==============================================================================
* MARCH 2023
*==============================================================================
di as result _n "{hline 70}" _n "March 2023" _n "{hline 70}"

* Not all Susenas rounds are the same. File names, the number of files a module is
* split into, and variable names all differ between rounds. Look in the folder and
* in the metadata workbook for this round before you type anything. The 2022 block
* above is the pattern; the 2025 round is the one that differs most.
*
* >>> write this round here <<<


*==============================================================================
* MARCH 2024
*==============================================================================
di as result _n "{hline 70}" _n "March 2024" _n "{hline 70}"

* Not all Susenas rounds are the same. File names, the number of files a module is
* split into, and variable names all differ between rounds. Look in the folder and
* in the metadata workbook for this round before you type anything. The 2022 block
* above is the pattern; the 2025 round is the one that differs most.
*
* >>> write this round here <<<


*==============================================================================
* MARCH 2025
*==============================================================================
di as result _n "{hline 70}" _n "March 2025" _n "{hline 70}"

* Not all Susenas rounds are the same. File names, the number of files a module is
* split into, and variable names all differ between rounds. Look in the folder and
* in the metadata workbook for this round before you type anything. The 2022 block
* above is the pattern; the 2025 round is the one that differs most.
*
* >>> write this round here <<<


*==============================================================================
* THE POVERTY LINE
*
* This is a PUBLISHED BPS table, not microdata, so the package ships the real
* figures rather than synthetic ones. It is defined at province by urban/rural
* and is constant inside each of those cells. Never average it to district
* level: for a district that is entirely urban you would blend in a rural line.
*==============================================================================
import delimited "$pkg/poverty_line_2022_2025.csv", clear varnames(1)
list in 1/4
save "$work/povline.dta", replace

di as result _n "Step 0 complete. Imported files are in $work"
