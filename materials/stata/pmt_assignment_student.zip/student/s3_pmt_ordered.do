*==============================================================================
* SYNTHETIC SUSENAS - PMT ASSIGNMENT
* Step 3: the PMT as an ordered probit, and the targeting errors of all four models
*
* Step 2 predicted a continuous welfare measure. This step goes at the target
* directly: the decile itself becomes the dependent variable. A decile is
* ordered - decile 3 really is between 2 and 4 - so ordered probit is the
* natural estimator.
*
*   3. ordered probit on the decile, the PMT's thirty-nine proxies, district effects
*   4. ordered probit on the decile, the parsimonious model, district effects
*   5. inclusion and exclusion error at the bottom 50 per cent, for the four
*      predictions of steps 2 and 3, on the 2025 test round
*
* A NOTE ON RUNTIME. An ordered model is fitted by maximum likelihood. With the
* proxies and the 514 district dummies it still converges in four or five
* iterations, about two and a half minutes each on a four-core machine.
*==============================================================================

clear all
set more off

if "$work" == "" global work "E:/pmtwb/synthetic_mc/work_assignment"      // a default; s_run_all.do sets it for all four files

* The two specifications of step 2, written out again so this file stands on its own.
global baseline_39                                    ///
    ln_hhsize                                         ///
    ln_hhsize_2                                       ///
    ln_h_luaslantai                                   ///
    ln_h_luaslantai_2                                 ///
    i.h_house                                         ///
    i.h_roof                                          ///
    i.h_wall                                          ///
    i.h_floor                                         ///
    i.h_toilet                                        ///
    i.h_closet                                        ///
    i.h_sewage                                        ///
    i.h_water                                         ///
    i.h_light                                         ///
    i.h_fuel                                          ///
    i.h_epower                                        ///
    h_asset_a h_asset_b h_asset_c h_asset_d           ///
    h_asset_e h_asset_f h_asset_g h_asset_h           ///
    h_asset_i h_asset_j h_asset_k h_asset_l h_asset_m ///
    n_age04 n_age519 n_age2064 n_age65up              ///
    n_female n_worker                                 ///
    h_married h_widowed                               ///
    h_neverschool h_stillschool                       ///
    head_female hd_age hd_edu

global predictors_7                                   ///
    ln_hhsize                                         ///
    ln_elec_kwh_pc                                    ///
    ln_telecom_cons_pc                                ///
    ln_hhsize_2                                       ///
    ln_elec_kwh_pc_2                                  ///
    ln_telecom_cons_pc_2                              ///
    h_epower2                                         ///
    h_epower3                                         ///
    ln_elec_kwh_pc_h_epower2                          ///
    ln_elec_kwh_pc_h_epower3                          ///
    h_asset_car                                       ///
    h_asset_computer                                  ///
    h_asset_land                                      ///
    ln_h_luaslantai                                   ///
    ln_h_luaslantai_2

use "$work/step2_predictions.dta", clear
tabulate year train


*==============================================================================
* 3. ORDERED PROBIT ON THE DECILE - THE PMT, DISTRICT FIXED EFFECTS
*
* One slope vector plus nine cutpoints. The cutpoints say where on the latent
* scale one decile ends and the next begins; unequal gaps mean the deciles are
* not equally spaced in terms of the proxies. Run quietly, printed without the
* district dummies, exactly as in step 2.
*==============================================================================
di as result _n "{hline 70}" _n "3. Ordered probit on the decile, the PMT, district fixed effects" _n "{hline 70}"
quietly oprobit decile $baseline_39 urban i.kode_kab if train == 1
estimates table, drop(i.kode_kab) b(%9.4f) se(%9.4f) stats(N r2_p) varwidth(28)
di as text "  log likelihood " as result %12.1f e(ll)

* Ten predicted probabilities per household, one for each decile.
predict double op1 op2 op3 op4 op5 op6 op7 op8 op9 op10, pr

* One number per household: the probability-weighted average decile. Step 5
* ranks it into deciles exactly as it ranks the linear prediction, so the two
* estimators are compared on the same footing.
generate double op_expected = 1 * op1 + 2 * op2 + 3 * op3 + 4 * op4 + 5 * op5 ///
                           + 6 * op6 + 7 * op7 + 8 * op8 + 9 * op9 + 10 * op10
summarize op_expected if train == 0


*==============================================================================
* 4. ORDERED PROBIT ON THE DECILE - THE PARSIMONIOUS MODEL, DISTRICT FIXED EFFECTS
*
* Same estimator, same district effects, the other list of proxies.
*==============================================================================
di as result _n "{hline 70}" _n "4. Ordered probit on the decile, the parsimonious model, district fixed effects" _n "{hline 70}"

* Same pattern as model 3, with the other list of proxies. Name the ten predicted
* probabilities ops1 ... ops10 and the expected decile ops_expected - section 5
* expects those names.
*
* >>> write model 4 here <<<


*==============================================================================
* 5. INCLUSION AND EXCLUSION ERROR AT THE BOTTOM 50 PER CENT
*
* The rule: rank the 2025 test round by a model's prediction, weighted by the
* individual weight so that a decile is a tenth of PEOPLE, and select the bottom
* half. The truly eligible are the bottom half of real per-capita expenditure,
* the `decile` variable built in step 1.
*
*   inclusion error: of those the rule SELECTS, the share that should not have been
*   exclusion error: of those who ARE eligible, the share the rule misses
*
* Both are weighted shares of people. Because the rule selects exactly as many
* as are eligible, the two errors are equal by construction - the number of
* wrongly selected equals the number of wrongly missed.
*
* The same block is written out four times, once per prediction.
*==============================================================================

*------------------------------------------------------------------------------
* 5a. the PMT, linear model (step 2, model 1)
*------------------------------------------------------------------------------
xtile d_pmt = yhat_pmt [fweight = weind] if train == 0, nquantiles(10)
quietly summarize weind if train == 0 & d_pmt <= 5, meanonly
scalar selected_pmt = r(sum)
quietly summarize weind if train == 0 & decile <= 5, meanonly
scalar eligible_pmt = r(sum)
quietly summarize weind if train == 0 & d_pmt <= 5 & decile > 5, meanonly
scalar ie_pmt = 100 * r(sum) / selected_pmt
quietly summarize weind if train == 0 & d_pmt > 5 & decile <= 5, meanonly
scalar ee_pmt = 100 * r(sum) / eligible_pmt

*------------------------------------------------------------------------------
* 5b. the parsimonious model, linear (step 2, model 2)
*------------------------------------------------------------------------------

* Same block as 5a, for yhat_pars (model 2).
* Keep the names selected_pars, eligible_pars, ie_pars and ee_pars:
* the table in 5e reads them, and stops with "ie_pars not found" until this
* block exists.
*
* >>> write this block here <<<

*------------------------------------------------------------------------------
* 5c. the PMT, ordered probit (model 3), expected decile
*------------------------------------------------------------------------------

* Same block as 5a, for op_expected (model 3).
* Keep the names selected_op, eligible_op, ie_op and ee_op:
* the table in 5e reads them, and stops with "ie_op not found" until this
* block exists.
*
* >>> write this block here <<<

*------------------------------------------------------------------------------
* 5d. the parsimonious model, ordered probit (model 4), expected decile
*------------------------------------------------------------------------------

* Same block as 5a, for ops_expected (model 4).
* Keep the names selected_ops, eligible_ops, ie_ops and ee_ops:
* the table in 5e reads them, and stops with "ie_ops not found" until this
* block exists.
*
* >>> write this block here <<<

*------------------------------------------------------------------------------
* 5e. the four models side by side
*------------------------------------------------------------------------------
di as result _n "{hline 70}"
di as result "5. Targeting the bottom 50 per cent of the 2025 test round"
di as result "{hline 70}"
di as text "  IE = inclusion error, EE = exclusion error, both in per cent of people"
di as result _n %-48s "model" %9s "IE50" %9s "EE50"
di as text %-48s "1. PMT, linear, district FE"                as result %9.2f scalar(ie_pmt)  %9.2f scalar(ee_pmt)
di as text %-48s "2. parsimonious, linear, district FE"       as result %9.2f scalar(ie_pars) %9.2f scalar(ee_pars)
di as text %-48s "3. PMT, ordered probit, district FE"        as result %9.2f scalar(ie_op)   %9.2f scalar(ee_op)
di as text %-48s "4. parsimonious, ordered probit, district FE" as result %9.2f scalar(ie_ops)  %9.2f scalar(ee_ops)
di as result "{hline 70}"

quietly save "$work/step3_predictions.dta", replace
di as result _n "Step 3 complete."
