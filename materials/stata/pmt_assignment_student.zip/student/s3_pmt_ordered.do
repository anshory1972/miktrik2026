*==============================================================================
* SYNTHETIC SUSENAS - PMT ASSIGNMENT
* Step 3: the PMT as an ordered probit, and the targeting errors of all four models
*
* Step 2 predicted a continuous welfare measure. This step goes at the target
* directly: the decile itself becomes the dependent variable. A decile is
* ordered - decile 3 really is between 2 and 4 - so ordered probit is the
* natural estimator.
*
*   3. ordered probit on the decile, the PMT's thirty-nine proxies, district effects
*   4. ordered probit on the decile, the parsimonious model, district effects
*   5. inclusion and exclusion error at the bottom 50 per cent, for the four
*      predictions of steps 2 and 3, on the 2025 test round
*
* A NOTE ON RUNTIME. An ordered model is fitted by maximum likelihood. With the
* proxies and the 514 district dummies it still converges in four or five
* iterations, about two and a half minutes each on a four-core machine.
*==============================================================================

clear all
set more off

* THE LINES TO EDIT before running this file:
*   work  the same folder you gave step 0; the earlier steps left their files there
global work "E:/pmtwb/synthetic_mc/work_assignment"
capture mkdir "$work"

* every step writes its own log into that folder; hand the four logs in with the do files
capture log close
log using "$work/s3_pmt_ordered.log", replace text

* The two specifications of step 2, written out again so this file stands on its own.
global baseline_39                                    ///
    ln_hhsize                                         ///
    ln_hhsize_2                                       ///
    ln_h_luaslantai                                   ///
    ln_h_luaslantai_2                                 ///
    i.h_house                                         ///
    i.h_roof                                          ///
    i.h_wall                                          ///
    i.h_floor                                         ///
    i.h_toilet                                        ///
    i.h_closet                                        ///
    i.h_sewage                                        ///
    i.h_water                                         ///
    i.h_light                                         ///
    i.h_fuel                                          ///
    i.h_epower                                        ///
    h_asset_a h_asset_b h_asset_c h_asset_d           ///
    h_asset_e h_asset_f h_asset_g h_asset_h           ///
    h_asset_i h_asset_j h_asset_k h_asset_l h_asset_m ///
    n_age04 n_age519 n_age2064 n_age65up              ///
    n_female n_worker                                 ///
    h_married h_widowed                               ///
    h_neverschool h_stillschool                       ///
    head_female hd_age hd_edu

global predictors_7                                   ///
    ln_hhsize                                         ///
    ln_elec_kwh_pc                                    ///
    ln_telecom_cons_pc                                ///
    ln_hhsize_2                                       ///
    ln_elec_kwh_pc_2                                  ///
    ln_telecom_cons_pc_2                              ///
    h_epower2                                         ///
    h_epower3                                         ///
    ln_elec_kwh_pc_h_epower2                          ///
    ln_elec_kwh_pc_h_epower3                          ///
    h_asset_car                                       ///
    h_asset_computer                                  ///
    h_asset_land                                      ///
    ln_h_luaslantai                                   ///
    ln_h_luaslantai_2

use "$work/step2_predictions.dta", clear
tabulate year train


*==============================================================================
* 3. ORDERED PROBIT ON THE DECILE - THE PMT, DISTRICT FIXED EFFECTS
*
* One slope vector plus nine cutpoints. The cutpoints say where on the latent
* scale one decile ends and the next begins; unequal gaps mean the deciles are
* not equally spaced in terms of the proxies. The output is Stata's, in full,
* district dummies included, exactly as in step 2.
*==============================================================================
di as result _n "{hline 70}" _n "3. Ordered probit on the decile, the PMT, district fixed effects" _n "{hline 70}"

* Fit the ordered probit of the decile on the PMT proxies, with an urban dummy
* and a fixed effect for every district, on the training rounds only; let Stata
* print its full output. Then take the ten predicted probabilities per
* household (op1 ... op10) and build the expected decile, op_expected: the
* probability-weighted average of the ten decile numbers. Summarize it on the
* test round.
*
* >>> write model 3 here <<<


*==============================================================================
* 4. ORDERED PROBIT ON THE DECILE - THE PARSIMONIOUS MODEL, DISTRICT FIXED EFFECTS
*
* Same estimator, same district effects, the other list of proxies.
*==============================================================================
di as result _n "{hline 70}" _n "4. Ordered probit on the decile, the parsimonious model, district fixed effects" _n "{hline 70}"

* The same, with the other list of proxies. Probabilities ops1 ... ops10,
* expected decile ops_expected.
*
* >>> write model 4 here <<<


*==============================================================================
* 5. INCLUSION AND EXCLUSION ERROR AT THE BOTTOM 50 PER CENT
*
* The rule: rank the 2025 test round by a model's prediction, weighted by the
* individual weight so that a decile is a tenth of PEOPLE, and select the bottom
* half. The truly eligible are the bottom half of real per-capita expenditure,
* the `decile` variable built in step 1.
*
*   inclusion error: of those the rule SELECTS, the share that should not have been
*   exclusion error: of those who ARE eligible, the share the rule misses
*
* Both are weighted shares of people. Because the rule selects exactly as many
* as are eligible, the two errors are equal by construction - the number of
* wrongly selected equals the number of wrongly missed.
*
* The same block is written out four times, once per prediction.
*==============================================================================

*------------------------------------------------------------------------------
* 5a. the PMT, linear model (step 2, model 1)
*------------------------------------------------------------------------------

* For yhat_pmt (model 1): rank the 2025 test round into ten weighted deciles
* of the score, select predicted deciles 1-5, and compute the inclusion and
* exclusion errors as defined above. Store them in the scalars ie_pmt and
* ee_pmt, in per cent; the table in 5e reads those names.
*
* >>> write this block here <<<

*------------------------------------------------------------------------------
* 5b. the parsimonious model, linear (step 2, model 2)
*------------------------------------------------------------------------------

* For yhat_pars (model 2): rank the 2025 test round into ten weighted deciles
* of the score, select predicted deciles 1-5, and compute the inclusion and
* exclusion errors as defined above. Store them in the scalars ie_pars and
* ee_pars, in per cent; the table in 5e reads those names.
*
* >>> write this block here <<<

*------------------------------------------------------------------------------
* 5c. the PMT, ordered probit (model 3), expected decile
*------------------------------------------------------------------------------

* For op_expected (model 3): rank the 2025 test round into ten weighted deciles
* of the score, select predicted deciles 1-5, and compute the inclusion and
* exclusion errors as defined above. Store them in the scalars ie_op and
* ee_op, in per cent; the table in 5e reads those names.
*
* >>> write this block here <<<

*------------------------------------------------------------------------------
* 5d. the parsimonious model, ordered probit (model 4), expected decile
*------------------------------------------------------------------------------

* For ops_expected (model 4): rank the 2025 test round into ten weighted deciles
* of the score, select predicted deciles 1-5, and compute the inclusion and
* exclusion errors as defined above. Store them in the scalars ie_ops and
* ee_ops, in per cent; the table in 5e reads those names.
*
* >>> write this block here <<<

*------------------------------------------------------------------------------
* 5e. the four models side by side
*------------------------------------------------------------------------------
di as result _n "{hline 70}"

* Print one table: a row per model (1 to 4), the inclusion error and the
* exclusion error at the bottom 50 per cent, two decimals, as in the reference
* output.
*
* >>> write the table here <<<

quietly save "$work/step3_predictions.dta", replace
di as result _n "Step 3 complete."
log close
